#!/bin/bash

sudo apt-get install python-pip
sudo apt install openjdk-8-jre-headless
sudo pip install --upgrade pip==9.0.1
sudo pip install androguard==3.2
